const url = require('url')
const fs = require('fs')
const sqlite3 = require('sqlite3').verbose() //verbose provides more detailed stack trace
//const db = new sqlite3.Database('data/db_1200iRealSongs')
//const db = new sqlite3.Database('data/db_1200iRealSongs.db')
const db = new sqlite3.Database('data/bookstore.db')

//notice navigation to parent directory:
const headerFilePath = __dirname + '/../views/header.html'
const footerFilePath = __dirname + '/../views/footer.html'
let currentSalesPeriod = '2022-12-1'
let thisOrderSales = 0
let thisOrderExpenditures = 0
sql = "INSERT OR REPLACE INTO Report (sales_period, sales, expenditures) VALUES (" + "'"+currentSalesPeriod+"'" + ", " + thisOrderSales + ", " + thisOrderExpenditures + ")"
console.log(sql)
db.all(sql, function(err, rows) {
  console.log('ROWS: ' + typeof rows)
})
db.serialize(function() {
  //make sure a couple of users exist in the database.
  //user: number: 0, fName Dustin, lName: Doyle, billing: dustBank, shipping: dusty street, password: dustyPW, type: owner
  //user: ldnel password: secret role: admin
  //user: frank password: secret2 role: guest
  //let sqlString = "CREATE TABLE IF NOT EXISTS User (userid TEXT PRIMARY KEY, password TEXT)"
  //db.run(sqlString)
  // sqlString = "INSERT OR REPLACE INTO User VALUES ('ldnel', 'secret', 'admin')"
  // db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO User VALUES (0, 'Dustin', 'Doyle', 'dustBank', 'dusty street', 'dustyPW', 'owner')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO User VALUES (1, 'Dustin2', 'Doyle2', 'dustBank2', 'dusty street2', 'dustyPW', 'customer')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Book VALUES (42069, 0.69, 420.69, 'Haha da funny', 420)"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Book VALUES (12300, 0.19, 40.69, 'Second book', 78)"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Author VALUES (42069, 'Meme Man')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Author VALUES (42069, 'Meme Mans Clone')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Genre VALUES (42069, 'Memes')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Genre VALUES (42069, 'Stale Memes')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Genre VALUES (42069, 'Very Stale Memes')"
  db.run(sqlString)
  sqlString = "INSERT OR REPLACE INTO Publish VALUES (42069, 'The One and Only Pub')"
  db.run(sqlString)
  // sqlString = "INSERT OR REPLACE INTO User VALUES ('frank', 'secret2', 'guest')"
  // db.run(sqlString)
  // sqlString = "INSERT OR REPLACE INTO User VALUES ('jesus', 'isSus', 'guest')"
  // db.run(sqlString)
})


exports.authenticate = function(request, response, next) {
  /*
	Middleware to do BASIC http 401 authentication
	*/
  let auth = request.headers.authorization
  // auth is a base64 representation of (username:password)
  //so we will need to decode the base64
  if (!auth) {
    //note here the setHeader must be before the writeHead
    response.setHeader('WWW-Authenticate', 'Basic realm="need to login"')
    response.writeHead(401, {
      'Content-Type': 'text/html'
    })
    console.log('No authorization found, send 401.')
    response.end();
  } else {
    console.log("Authorization Header: " + auth)
    //decode authorization header
    // Split on a space, the original auth
    //looks like  "Basic Y2hhcmxlczoxMjM0NQ==" and we need the 2nd part
    var tmp = auth.split(' ')

    // create a buffer and tell it the data coming in is base64
    var buf = Buffer.from(tmp[1], 'base64');

    // read it back out as a string
    //should look like 'ldnel:secret'
    var plain_auth = buf.toString()
    console.log("Decoded Authorization ", plain_auth)

    //extract the userid and password as separate strings
    var credentials = plain_auth.split(':') // split on a ':'
    var username = credentials[0]
    var password = credentials[1]
    console.log("User: ", username)
    console.log("Password: ", password)

    var authorized = false
    //check database User table for user
    db.all("SELECT fName, lName, password, type, number FROM User", function(err, rows) {
      for (var i = 0; i < rows.length; i++) {
        if ((rows[i].fName + " " + rows[i].lName) == username & rows[i].password == password) {
          authorized = true
          request.user_role = rows[i].type
          request.user_number = rows[i].number
        }
      }
      if (authorized == false) {
        //we had an authorization header by the user:password is not valid
        response.setHeader('WWW-Authenticate', 'Basic realm="need to login"')
        response.writeHead(401, {
          'Content-Type': 'text/html'
        })
        console.log('No authorization found, send 401.')
        response.end()
      } else
        next()
    })
  }

  //notice no call to next()

}

function handleError(response, err) {
  //report file reading error to console and client
  console.log('ERROR: ' + JSON.stringify(err))
  //respond with not found 404 to client
  response.writeHead(404)
  response.end(JSON.stringify(err))
}

/*
CAN YOU FIND A BETTER WAY TO HANDLE THE NEXT THREE CUT AND PASTE FUNCTIONS:
*/

function send_find_data(request, response, rows) {
  /*
  This code assembles the response from two partial .html files
  with the data placed between the two parts
  This CLUMSY approach is done here to motivivate the need for
  template rendering. Here we use basic node.js file reading to
  simulate placing data within a file.
  */
  //notice navigation to parent directory:
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)

    //INSERT DATA
    for (let row of rows) {
      response.write(`<p><a href= 'book/${row.ISBN}'>${row.ISBN} ${row.title}</a></p>`)
    }

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function send_book_details(request, response, rows) {
  /*
  This code assembles the response from two partial .html files
  with the data placed between the two parts
  This CLUMSY approach is done here to motivivate the need for
  template rendering. Here we use basic node.js file reading to
  simulate placing data within a file.
  */
  //notice navigation to parent directory:
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)

    //INSERT DATA
    for (let row of rows) {
      console.log(row)
      response.write(`<h1>Books Details:</h1>`)
      response.write(`<h1>| Books ISBN: ${row.ISBN} | Books Title: ${row.title} | Number of Pages: ${row.number_of_pages} | Sales Percent: ${row.sales_percent} | Price: ${row.price} |</h1>`)
      sql = "SELECT publisher_name FROM Publish WHERE ISBN = " + row.ISBN 
      db.all(sql, function(err, rows2) {
        for (let row2 of rows2) {
          console.log('ROWS: ' + typeof rows2)
          response.write(`<h1>| Books Publisher: ${row2.publisher_name} |</h1>`)
        }
      })
      sql = "SELECT genre FROM Genre WHERE ISBN = " + row.ISBN 
      db.all(sql, function(err, rows3) {
        for (let row3 of rows3) {
          response.write(`<h1>| Books Genres: ${row3.genre} |</h1>`)
        }
      })
      sql = "SELECT author_name FROM Author WHERE ISBN = " + row.ISBN 
      db.all(sql, function(err, rows4) {
        for (let row4 of rows4) {
          response.write(`<h1>| Books Authors: ${row4.author_name} |</h1>`)
        }
      })
      // response.write(`<h1>Books Details:</h1>`)
      // response.write(`<h1>| Books ISBN: ${row.ISBN} | Books Title: ${row.title} | Number of Pages: ${row.number_of_pages} | Sales Percent: ${row.sales_percent} | Price: ${row.price} |</h1>`)
      // response.write(`<h1>| Books Genres: ${row2.ISBN} | Books Authors: ${row.title} | Books Publisher: ${row.number_of_pages} |</h1>`)
      //response.write(`<p>${row.bars}</p>`)
    }

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function send_users(request, response, rows) {
  /*
  This code assembles the response from two partial .html files
  with the data placed between the two parts
  This CLUMSY approach is done here to motivivate the need for
  template rendering. Here we use basic node.js file reading to
  simulate placing data within a file.
  */

  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)

    //INSERT DATA
    for (let row of rows) {
      console.log(row)
      response.write(`<p>| Full Name: ${row.fName + " " + row.lName} | Number: ${row.number} | Billing Info: ${row.billing} | Shipping Info: ${row.shipping} | Password: ${row.password} | User Type: ${row.type} |</p>`)
    }

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function add_book(request, response, rows) {
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)
    //console.log(rows)
    response.write(`<h1>Added the book created by this url query: "${request.url}"</h1>`)

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function remove_book(request, response, rows) {
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)
    //console.log(rows)
    response.write(`<h1>All Books that are found by the url query: "${request.url}" have been Removed</h1>`)
    //INSERT DATA
    // for (let row of rows) {
    //   console.log(row)
    //   response.write(`<h1>Books Removed:</h1>`)
    //   //response.write(`<h1>| Books ISBN: ${row.ISBN} | Books Title: ${row.title} | Number of Pages: ${row.number_of_pages} | Sales Percent: ${row.sales_percent} | Price: ${row.price} |</h1>`)
    //   // //response.write(`<p>${row.bars}</p>`)
    // }

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function add_OrderToCart(request, response, rows) {
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)
    response.write("Order was added to Cart")
    // response.write(data)
    // //console.log(rows)
    // response.write(`<h1>Added the book created by this url query: "${request.url}"</h1>`)

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function add_OrderCheckOut(request, response, rows) {
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)
    response.write("Cart has been checked out")
    // response.write(data)
    // //console.log(rows)
    // response.write(`<h1>Added the book created by this url query: "${request.url}"</h1>`)

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function send_reports(request, response, rows) {
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)

    //INSERT DATA
    for (let row of rows) {
      console.log(row)
      response.write(`<p>| Sales Period: ${row.sales_period} | Sales: ${row.sales} | Expenditures: ${row.expenditures} |</p>`)
    }
    sql = "SELECT * FROM Sales_per_genre"
    db.all(sql, function(err, rows) {
      console.log('ROWS: ' + typeof rows)
      for (let row of rows) {
        console.log(row)
        response.write(`<p>| Sales Period: ${row.report_sales_period} | Sales: ${row.sales_per_genre} | Genre: ${row.genre} |</p>`)
      }
    })

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}


exports.index = function(request, response) {
  // index.html
  fs.readFile(headerFilePath, function(err, data) {
    if (err) {
      handleError(response, err);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write(data)

    //INSERT DATA -no data to insert

    fs.readFile(footerFilePath, function(err, data) {
      if (err) {
        handleError(response, err);
        return;
      }
      response.write(data)
      response.end()
    })
  })
}

function parseURL(request, response) {
  const PARSE_QUERY = true //parseQueryStringIfTrue
  const SLASH_HOST = true //slashDenoteHostIfTrue
  let urlObj = url.parse(request.url, PARSE_QUERY, SLASH_HOST)
  console.log('path:')
  console.log(urlObj.path)
  console.log('query:')
  console.log(urlObj.query)
  return urlObj

}

exports.users = function(request, response) {
  // /send_users
  console.log('USER TYPE: ' + request.user_role)


  if(request.user_role !== 'owner'){
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write('<h2>ERROR: Owner Privileges Required To See Users</h2>')
    response.end()
    return
  }
  db.all("SELECT number, fName, lName, billing, shipping, password, type FROM User", function(err, rows) {
    send_users(request, response, rows)
  })

}

exports.reports = function(request, response) {
  // /send_reports
  console.log('USER TYPE: ' + request.user_role)


  if(request.user_role !== 'owner'){
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write('<h2>ERROR: Owner Privileges Required To See Reports</h2>')
    response.end()
    return
  }
  db.all("SELECT sales_period, sales, expenditures FROM Report", function(err, rows) {
    send_reports(request, response, rows)
  })

}

exports.addOrderToCart = function(request, response) {
  let newBookArray = []
  let urlObj = parseURL(request, response)
  console.log(urlObj)
  if (urlObj.query['ISBN']) {
    newBookArray[0] = urlObj.query['ISBN']
  }
  if (urlObj.query['quantity']) {
    newBookArray[1] = urlObj.query['quantity']
  }

  let sql = "INSERT INTO Cart_orders (user_number, ISBN, quantity) VALUES (" + request.user_number + ", " + parseInt(newBookArray[0]) + ", " + parseInt(newBookArray[1]) + ")"
  //let sql = "INSERT INTO Book (ISBN, sales_percent, price, title, number_of_pages) VALUES (100001, 24, 15.99, 'newBook', 39)"
  console.log(sql)
  db.all(sql, function(err, rows) {
    console.log('ROWS: ' + typeof rows)
    add_OrderToCart(request, response, rows)
  })
}

exports.checkoutCart = function(request, response) {
  let newBookArray = []
  let urlObj = parseURL(request, response)
  console.log(urlObj)
  if (urlObj.query['billing']) {
    newBookArray[0] = urlObj.query['billing']
  }
  if (urlObj.query['shipping']) {
    newBookArray[1] = urlObj.query['shipping']
  }

  let sql = "INSERT INTO BookOrder (user_number, billing, shipping) VALUES (" + request.user_number + ", " + "'"+newBookArray[0]+"'" + ", " + "'"+newBookArray[1]+"'" + ")"
  console.log(sql)
  let orderNum
  db.all(sql, function(err, rows) {
    console.log('ROWS: ' + typeof rows)
  })
  //This gets most recently added book order number so I can use it in contains
  sql = "SELECT number FROM BookOrder ORDER BY number DESC LIMIT 1"
    db.all(sql, function(err, rows) {
      console.log("this test: " + rows)
      for (let row of rows) {
        console.log(row.number)
        orderNum = row.number
      }
    })
   
  //orderNum
  sql = "SELECT ISBN, quantity FROM Cart_orders WHERE user_number=" + request.user_number
  console.log(sql)
  //sql = "INSERT INTO Contains (order_number, ISBN, quantity) VALUES (" + orderNum + ", " + ")"
  db.all(sql, function(err, rows) {
    console.log(rows)
    // console.log('ROWS: ' + typeof rows)
    for (let row of rows) {
      sql = "INSERT INTO Contains (order_number, ISBN, quantity) VALUES (" + orderNum + ", " + row.ISBN + ", " + row.quantity + ")"
      console.log(sql)
      db.all(sql, function(err, rows) {
        console.log('ROWS: ' + typeof rows)
      })
    }
    //Update the reports based on the added order
    console.log(currentSalesPeriod)
    sql = "INSERT INTO Update_Report (order_number, report_sales_period) VALUES (" + orderNum + ", " + "'"+currentSalesPeriod+"'" + ")"
    console.log(sql)
    db.all(sql, function(err, rows) {
      console.log('ROWS: ' + typeof rows)
    })
    //Get sales and expenditures by using contains to get the complete list of books which we will use to get the book information multiplied by the quantity of books stored with it's ISBN in contains
    // let thisOrderSales = 0
    // let thisOrderExpenditures = 0
    sql = "SELECT ISBN, quantity FROM Contains WHERE order_number=" + orderNum
    console.log(sql)
    db.all(sql, function(err, rows) {
      console.log('ROWS: ' + typeof rows)
      //Loop through the book orders in contains
      let backupInt = 0
      for (let row of rows) {
        // backupInt += 1
        sql = "SELECT sales_percent, price FROM Book WHERE ISBN=" + row.ISBN
        console.log(sql)
        db.all(sql, function(err, rows2) {
          for (let row2 of rows2) {
            console.log("What is this orders Expenditures: " + ((row2.price)*row2.sales_percent)*row.quantity)
            console.log("What is this orders Sales: " + (row2.price - ((row2.price)*row2.sales_percent))*row.quantity)
            thisOrderExpenditures += ((row2.price)*row2.sales_percent)*row.quantity
            thisOrderSales += (row2.price - ((row2.price)*row2.sales_percent))*row.quantity
            //console.log(thisOrderExpenditures)
            //backupInt += 1

            //sql = "INSERT INTO Report (sales_period, sales, expenditures) VALUES (" + "'"+currentSalesPeriod+"'" + ", " + thisOrderSales + ", " + thisOrderExpenditures + ")"
            sql = "INSERT OR REPLACE INTO Report (sales_period, sales, expenditures) VALUES (" + "'"+currentSalesPeriod+"'" + ", " + thisOrderSales + ", " + thisOrderExpenditures + ")"
            console.log(sql)
            db.all(sql, function(err, rows) {
              console.log('ROWS: ' + typeof rows)
            })
            //Get all genres for this book
            sql = "SELECT genre FROM Genre WHERE ISBN=" + row.ISBN
            console.log(sql)
            db.all(sql, function(err, rows8) {
              console.log('ROWS8: ' + typeof rows8)
              for (let row8 of rows8) {
                sql = "SELECT sales_per_genre FROM Sales_per_genre WHERE report_sales_period = " + "'"+currentSalesPeriod+"'" + " AND " + "genre = " + "'"+row8.genre+"'"
                console.log(sql)
                db.all(sql, function(err, rows4) {
                  console.log('ROWS4: ' + typeof rows4)
                  console.log(rows4)
                  if(rows4.length !== 0){
                    for (let row4 of rows4) {
                      let newSalesByGenere = row4.sales_per_genre += (row2.price - ((row2.price)*row2.sales_percent))*row.quantity
                      sql = "INSERT OR REPLACE INTO Sales_per_genre (sales_per_genre, report_sales_period, genre) VALUES (" + newSalesByGenere + ", " + "'"+currentSalesPeriod+"'" + ", " + "'"+row8.genre+"'" + ")"
                      db.all(sql, function(err, rows) {
                        console.log('ROWS: ' + typeof rows)
                      })
                    }
                  } else {
                    let newSalesByGenere = (row2.price - ((row2.price)*row2.sales_percent))*row.quantity
                    sql = "INSERT OR REPLACE INTO Sales_per_genre (sales_per_genre, report_sales_period, genre) VALUES (" + newSalesByGenere + ", " + "'"+currentSalesPeriod+"'" + ", " + "'"+row8.genre+"'" + ")"
                    db.all(sql, function(err, rows) {
                      console.log('ROWS: ' + typeof rows)
                    })
                  }
                })
              }
            })
          }
        })
      }
      
      sql = "INSERT OR REPLACE INTO Report (sales_period, sales, expenditures) VALUES (" + "'"+currentSalesPeriod+"'" + ", " + thisOrderSales + ", " + thisOrderExpenditures + ")"
      console.log(sql)
      db.all(sql, function(err, rows) {
        console.log('ROWS: ' + typeof rows)
      })

    })

    add_OrderCheckOut(request, response, rows)
  })

}

exports.addBook = function(request, response) {
  if(request.user_role !== 'owner'){
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write('<h2>ERROR: Owner Privileges Required To Add Books</h2>')
    response.end()
    return
  }
  console.log(request.url)
  let newBookArray = []
  let urlObj = parseURL(request, response)
  console.log(urlObj)
  if (urlObj.query['ISBN']) {
    newBookArray[0] = urlObj.query['ISBN']
  }
  if (urlObj.query['sales_percent']) {
    newBookArray[1] = urlObj.query['sales_percent']
  }
  if (urlObj.query['price']) {
    newBookArray[2] = urlObj.query['price']
  }
  if (urlObj.query['title']) {
    newBookArray[3] = urlObj.query['title']
  }
  if (urlObj.query['number_of_pages']) {
    newBookArray[4] = urlObj.query['number_of_pages']
  }
  console.log(newBookArray)
  //Add book to db based on parameters from url
  let sql = "INSERT INTO Book (ISBN, sales_percent, price, title, number_of_pages) VALUES (" + parseInt(newBookArray[0]) + ", " + parseFloat(newBookArray[1]) + ", " + parseFloat(newBookArray[2]) + ", " + "'"+newBookArray[3]+"'" + ", " + parseInt(newBookArray[4]) + ")"
  //let sql = "INSERT INTO Book (ISBN, sales_percent, price, title, number_of_pages) VALUES (100001, 24, 15.99, 'newBook', 39)"
  console.log(sql)
  db.all(sql, function(err, rows) {
    console.log('ROWS: ' + typeof rows)
    add_book(request, response, rows)
  })
}

exports.removeBook = function(request, response) {
  if(request.user_role !== 'owner'){
    response.writeHead(200, {
      'Content-Type': 'text/html'
    })
    response.write('<h2>ERROR: Owner Privileges Required To Remove Books</h2>')
    response.end()
    return
  }
  console.log("RUNNING FIND BOOKS INSIDE OF REMOVE BOOK")

  let urlObj = parseURL(request, response)
  let sql = "SELECT ISBN, title FROM Book"

  if (urlObj.query['title']) {
    let keywords = urlObj.query['title']
    keywords = keywords.replace(/\s/g, '%')
    console.log("finding title: " + keywords);
    sql = "DELETE FROM Book WHERE title LIKE '%" +
      keywords + "%'"
  }

  db.all(sql, function(err, rows) {
    console.log('ROWS: ' + typeof rows)
    remove_book(request, response, rows)
  })
}

exports.find = function(request, response) {
  // /songs?title=Girl
  console.log("RUNNING FIND BOOKS")

  let urlObj = parseURL(request, response)
  let sql = "SELECT ISBN, title FROM Book"

  if (urlObj.query['title']) {
    let keywords = urlObj.query['title']
    keywords = keywords.replace(/\s/g, '%')
    console.log("finding title: " + keywords);
    sql = "SELECT ISBN, title FROM Book WHERE title LIKE '%" +
      keywords + "%'"
  }

  db.all(sql, function(err, rows) {
    console.log('ROWS: ' + typeof rows)
    send_find_data(request, response, rows)
  })
}

exports.bookDetails = function(request, response) {
  // /song/235
  let urlObj = parseURL(request, response)
  let bookISBN = urlObj.path
  bookISBN = bookISBN.substring(bookISBN.lastIndexOf("/") + 1, bookISBN.length)

  let sql = "SELECT ISBN, title, number_of_pages, sales_percent, price FROM Book WHERE ISBN=" + bookISBN
  console.log("GET BOOK DETAILS: " + bookISBN)

  db.all(sql, function(err, rows) {
    // sql = "SELECT publisher_name FROM publish WHERE ISBN EQUALS "
    // db.all(sql, function(err, rows2) {
      console.log('Book Details Data')
      send_book_details(request, response, rows)
    //})
  })
}
